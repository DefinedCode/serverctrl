rake setup:start RAILS_ENV="production"
