require 'test_helper'

class ServerControlHelperTest < ActionView::TestCase
end
