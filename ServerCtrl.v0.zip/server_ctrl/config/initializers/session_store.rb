# Be sure to restart your server when you modify this file.

ServerCtrl::Application.config.session_store :cookie_store, key: '_server_ctrl_session'
