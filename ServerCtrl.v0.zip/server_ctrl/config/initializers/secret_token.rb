# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
ServerCtrl::Application.config.secret_key_base = '9de89b5bfd4e8dafa7e653c98f31ce783cd45a1d467e1278c105089f79e1fe407a1157bc8b423f7e99c44848f0503dafb671a192d2036102539e1bf5e9e1f258'
